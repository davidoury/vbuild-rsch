ansible-playbook /etc/ansible/1-build.yaml --tags all --extra-vars "user=root"
