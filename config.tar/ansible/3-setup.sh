ansible-playbook /vagrant/ansible/3-setup.yaml \
	--tags setup_basics,setup_spark,setup_dsc,setup_hadoop,setup_r
