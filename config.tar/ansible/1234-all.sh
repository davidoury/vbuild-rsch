/etc/ansible/1-build.sh
/etc/ansible/2-accounts.sh
/etc/ansible/3-setup.sh
/etc/ansible/4-start.sh
