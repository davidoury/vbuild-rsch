ansible-playbook /etc/ansible/4-manage.yaml --tags stop_hdfs_namenode,stop_hdfs_datanodes,stop_dsc_seeds,stop_dsc_nonseeds,stop_rstudio_server
